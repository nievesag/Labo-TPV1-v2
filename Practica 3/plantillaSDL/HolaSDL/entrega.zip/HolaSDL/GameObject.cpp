#include "GameObject.h"

GameObject::GameObject()
{
}

GameObject::GameObject(Game* g) : game(g)
{
}

GameObject::~GameObject()
{
}